<?php if ( ! defined( 'BASEPATH')) exit( 'No direct script access allowed');
 

  public function hi() { 
 	$CI =& get_instance();
  	echo "hi"; 
  } 




   ?>
