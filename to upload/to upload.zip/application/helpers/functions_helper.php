<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


    function hi()
    {
        echo "hi";
    }   
