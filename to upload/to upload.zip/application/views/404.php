<div class="middle">
    <div class="container">
        <div class="row">

        <h1 style="margin:0; font-size:150px; line-height:150px; font-weight:bold;">404</h1>
<h2 style="margin-top:20px;font-size: 30px;">Page Not Found
</h2>
<p>The page you requested was not found.</p>

</div>
</div>
</div>