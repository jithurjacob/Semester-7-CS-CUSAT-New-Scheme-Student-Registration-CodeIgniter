<?php
echo "<script>alert('login to continue');document.location='".base_url()."';</script>";

 exit(0);
?>