<div class="middle">
    <div class="container">

        <div class="row about">
            <div class="col-md-12">
                <div class="responsive-table">
                    <table class="table table-condensed text-left">
                        <tr>
                            <td >
                                <br>
                                <h2>Developers</h2>
                            </td>
                        </tr>
                         <tr  style="height:80px">
                            <td class="text-center"><h3>Staff in Charge : Manoj S Nair</h3></td>
                            
                        </tr>
                        <tr>
                            <td class="text-center"><h5>Department of Computer Science</h5></td>
                        </tr>
                       <tr>
                            <td class="text-center"><h5>Email : <a style="color:black" href="mailto:iammanojsnair@gmail.com">iammanojsnair (at) gmail (dot) com</a></h5></td>
                        </tr>
                        <tr>
                            <td class="text-center"><h5>Phone : <a style="color:black" >+919447810070</a></h5></td>
                        </tr>
                         <tr  style="height:30px">
                            <td class="text-center"><h3>Developer : <a style="color:black;" target="_blank" href="https://www.facebook.com/jithurjacob007">Jithu R Jacob</a></h3></td>
                            
                        </tr>
                        <tr>
                            <td class="text-center"><h5>Department of Computer Science 2011 - 2015 Batch</h5></td>
                        </tr>
                       <tr>
                            <td class="text-center"><h5>Email : <a style="color:black" href="mailto:jithurjacob@gmail.com">jithurjacob (at) gmail (dot) com</a></h5></td>
                        </tr>
                        <tr>
                            <td class="text-center"><h5>Phone : <a style="color:black" >+918547924342</a></h5></td>
                        </tr>
                        
                        <tr style="height:50px"></tr>
                    </table>
                </div>
            </div>
           
        </div>


    </div>




</div>
