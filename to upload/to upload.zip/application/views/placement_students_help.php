<div class="middle">
    <div class="container">
        <div class="row about">
            <div class="col-md-12">
                <div class="home_steps well text-justify noborder">
                    <h2>Help</h2>
                    <br>
                    <br>
                    <div class="panel-group" id="accordion">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                Unverified Marks      </a>
                                </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                                <div class="panel-body">
                                    Your marks are indicated as unverified as the exam coordinator of your batch hasnot verified your marks.Please contact him/her immediately.Your marks wouldn't be shown to companies or used for computing class average 
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">         Invalid Marks      </a> 
                                </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse">
                                <div class="panel-body">
                                     Your marks are indicated as invalid as the exam coordinator of your batch verified the marks you provided as imcorrect.Kindly correct your marks by editing them.Please not that providing incorrect marks may end up in TERMINATION of your account.
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">      Privacy Settings       </a> 
                                </h4>
                            </div>
                            <div id="collapseThree" class="panel-collapse collapse">
                                <div class="panel-body">
                                    Other students could look up your details by using the search facility.You could manage what others could view about you.You could manage privacy settings like Profile Picture,Personal Details,Academic Details and Resume.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
