<div class="middle">
    <div class="container">
        <!-- <div class="row about">
            
        </div> -->
        <div class="row about">
            <div class="col-md-9">
                <div class="home_steps well text-justify noborder">
                    <!-- slider -->
                    <div class="row slider ">
                        <div class="col-md-12">
                            <div class="bs-example">
                                <div id="carousel-example-captions" class="carousel slide " data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carousel-example-captions" data-slide-to="0" class="active"></li>
                                        <li data-target="#carousel-example-captions" data-slide-to="1" class=""></li>
                                        <li data-target="#carousel-example-captions" data-slide-to="2" class=""></li>
                                        <li data-target="#carousel-example-captions" data-slide-to="3" class=""></li>
                                    </ol>
                                    <div class="carousel-inner">
                                        <div class="item active">
                                            <img alt="slider image 1" src="<?php echo base_url();?>css/images/slide/1.jpg" class="img-responsive center-block">
                                            <div class="carousel-caption">
                                                <h3>First slide label</h3>
                                                <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <img alt="slider image 2" src="<?php echo base_url();?>css/images/slide/2.jpg" class="img-responsive center-block">
                                            <div class="carousel-caption">
                                                <h3>Second slide label</h3>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <img alt="slider image 3" src="<?php echo base_url();?>css/images/slide/3.jpg" class="img-responsive center-block">
                                            <div class="carousel-caption">
                                                <h3>Second slide label</h3>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <img  alt="slider image 4" src="<?php echo base_url();?>css/images/slide/4.jpg" class="img-responsive center-block">
                                            <div class="carousel-caption">
                                                <h3>Third slide label</h3>
                                                <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <a class="left carousel-control" href="#carousel-example-captions" data-slide="prev">
                                        <span class="glyphicon glyphicon-chevron-left"></span>
                                    </a>
                                    <a class="right carousel-control" href="#carousel-example-captions" data-slide="next">
                                        <span class="glyphicon glyphicon-chevron-right"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- slider -->
                    
                <br>
                <br>
                
                
                <p>CUSAT EXAM CELL</p>
                
                <br>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <br>
                <br>
                 <br>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
                <br>
                <br>
            </div>
        </div>
        <div class="col-md-3">
            <div class="row">
                <div class="col-md-12 events well text-justify home_steps" id="events">
                    <?php $this->view('exam_news',$news_data); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 login_sidebar events well text-justify home_steps" id="login_sidebar">
                    <?php $this->view('exam_login_sidebar'); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>