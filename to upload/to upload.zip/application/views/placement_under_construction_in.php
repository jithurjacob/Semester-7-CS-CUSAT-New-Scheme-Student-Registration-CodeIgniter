<div class="middle">
    <div class="container">

        <div class="row about">
            <div class="col-md-12">
<?php //$this->view('under_construction');?>

<div id="uc_div">
            <?php $this->load->view('under_construction/index.php'); ?>
            </div>

</div>
            
        </div>


    </div>




</div>


