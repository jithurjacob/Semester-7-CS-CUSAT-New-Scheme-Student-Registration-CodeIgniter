<div class="secondary">
    <div class="container">
        <div id="secondary_wrap" class="row">
            <div class="col-md-3">
            <h5 class="address_title"><strong>ADDRESS</strong></h5>
                <address>
                    <strong>Cochin University</strong>
                    
                    <br>Kochi
                    <br>Ernakulam
                    <br>123456
                    <br>
                    <br>
                    <div><span class="glyphicon glyphicon-phone-alt"></span><a>04822-271737</a></div><!-- 
                    <div><span class="glyphicon glyphicon-earphone"></span><a href="#">+918547924342</a></div> -->
                <div>  <span class="glyphicon glyphicon-envelope"></span>
                <a href="mailto:exam@cusat.ac.in">exam (at) cusat (dot) ac (dot) in</a></div>
                </address>
            </div>
             <div class="col-md-3">
                <ul>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                </ul>
            </div><div class="col-md-3">
                <ul>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                    <li>
                        <a >Important Links</a>
                    </li>
                </ul>
            </div>
            
            

        </div>
    </div>
</div>
