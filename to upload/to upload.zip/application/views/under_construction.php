<!--<img src="<?php //echo base_url();?>css/images/under_construction.png" alt="Page under construction" 
class="img-responsive center-block inline ">-->

<div id="uc_div">
            <?php $this->load->view('under_construction/index.php'); ?>
 </div>
           