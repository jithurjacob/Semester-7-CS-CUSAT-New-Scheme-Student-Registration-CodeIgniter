<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-10-08 17:28:26 --> Config Class Initialized
DEBUG - 2014-10-08 17:28:26 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:28:26 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:28:26 --> URI Class Initialized
DEBUG - 2014-10-08 17:28:26 --> Router Class Initialized
DEBUG - 2014-10-08 17:29:00 --> Config Class Initialized
DEBUG - 2014-10-08 17:29:00 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:29:00 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:29:00 --> URI Class Initialized
DEBUG - 2014-10-08 17:29:00 --> Router Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Config Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:29:06 --> URI Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Router Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Output Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Security Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Input Class Initialized
DEBUG - 2014-10-08 17:29:06 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:06 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:06 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:06 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:06 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:06 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:06 --> CRSF cookie Set
DEBUG - 2014-10-08 17:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:29:06 --> Language Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Loader Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:29:06 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:29:06 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:29:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:29:06 --> Session Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:29:06 --> Session routines successfully run
DEBUG - 2014-10-08 17:29:06 --> Controller Class Initialized
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:29:06 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:06 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:29:06 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:29:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:29:06 --> Final output sent to browser
DEBUG - 2014-10-08 17:29:06 --> Total execution time: 0.2009
DEBUG - 2014-10-08 17:29:12 --> Config Class Initialized
DEBUG - 2014-10-08 17:29:12 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:29:12 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:29:12 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:29:12 --> URI Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Router Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Output Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Security Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Input Class Initialized
DEBUG - 2014-10-08 17:29:13 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:13 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:13 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:13 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:13 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:13 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:13 --> CRSF cookie Set
DEBUG - 2014-10-08 17:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:29:13 --> Language Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Loader Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:29:13 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:29:13 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:29:13 --> Session Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:29:13 --> Session routines successfully run
DEBUG - 2014-10-08 17:29:13 --> Controller Class Initialized
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:29:13 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:13 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:29:13 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:29:13 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:29:13 --> Final output sent to browser
DEBUG - 2014-10-08 17:29:13 --> Total execution time: 0.3451
DEBUG - 2014-10-08 17:29:44 --> Config Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:29:44 --> URI Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Router Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Output Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Security Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Input Class Initialized
DEBUG - 2014-10-08 17:29:44 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:44 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:44 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:44 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:44 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:44 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:44 --> CRSF cookie Set
DEBUG - 2014-10-08 17:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:29:44 --> Language Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Loader Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:29:44 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:29:44 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:29:44 --> Session Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:29:44 --> Session routines successfully run
DEBUG - 2014-10-08 17:29:44 --> Controller Class Initialized
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:29:44 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:44 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:29:44 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:29:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:29:44 --> Final output sent to browser
DEBUG - 2014-10-08 17:29:44 --> Total execution time: 0.1920
DEBUG - 2014-10-08 17:29:52 --> Config Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:29:52 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:29:52 --> URI Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Router Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Output Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Security Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Input Class Initialized
DEBUG - 2014-10-08 17:29:52 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:52 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:52 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:52 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:52 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:52 --> XSS Filtering completed
DEBUG - 2014-10-08 17:29:52 --> CRSF cookie Set
DEBUG - 2014-10-08 17:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:29:52 --> Language Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Loader Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:29:52 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:29:52 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:29:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:29:52 --> Session Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:29:52 --> Session routines successfully run
DEBUG - 2014-10-08 17:29:52 --> Controller Class Initialized
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:29:52 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:52 --> Model Class Initialized
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:29:52 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:29:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:29:52 --> Final output sent to browser
DEBUG - 2014-10-08 17:29:52 --> Total execution time: 0.1764
DEBUG - 2014-10-08 17:30:03 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:03 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:03 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Output Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Security Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Input Class Initialized
DEBUG - 2014-10-08 17:30:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:03 --> CRSF cookie Set
DEBUG - 2014-10-08 17:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:30:03 --> Language Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Loader Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:30:03 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:30:03 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:30:03 --> Session Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:30:03 --> Session routines successfully run
DEBUG - 2014-10-08 17:30:03 --> Controller Class Initialized
DEBUG - 2014-10-08 17:30:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:30:03 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:30:03 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:03 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:04 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:30:04 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:30:04 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:30:04 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:30:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:30:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:30:04 --> Final output sent to browser
DEBUG - 2014-10-08 17:30:04 --> Total execution time: 0.2363
DEBUG - 2014-10-08 17:30:05 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:05 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:05 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Output Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Security Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Input Class Initialized
DEBUG - 2014-10-08 17:30:05 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:05 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:05 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:05 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:05 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:05 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:05 --> CRSF cookie Set
DEBUG - 2014-10-08 17:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:30:05 --> Language Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Loader Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:30:05 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:30:05 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:30:05 --> Session Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:30:05 --> Session routines successfully run
DEBUG - 2014-10-08 17:30:05 --> Controller Class Initialized
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:30:05 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:05 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:30:05 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:30:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:30:05 --> Final output sent to browser
DEBUG - 2014-10-08 17:30:05 --> Total execution time: 0.2193
DEBUG - 2014-10-08 17:30:19 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:19 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:19 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Output Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Security Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Input Class Initialized
DEBUG - 2014-10-08 17:30:19 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:19 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:19 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:19 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:19 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:19 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:19 --> CRSF cookie Set
DEBUG - 2014-10-08 17:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:30:19 --> Language Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Loader Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:30:19 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:30:19 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:30:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:30:19 --> Session Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:30:19 --> Session routines successfully run
DEBUG - 2014-10-08 17:30:19 --> Controller Class Initialized
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:30:19 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:19 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:30:19 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:30:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:30:19 --> Final output sent to browser
DEBUG - 2014-10-08 17:30:19 --> Total execution time: 0.2021
DEBUG - 2014-10-08 17:30:23 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:23 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:23 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:23 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:23 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:28 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:28 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Output Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Security Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Input Class Initialized
DEBUG - 2014-10-08 17:30:28 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:28 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:28 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:28 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:28 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:28 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:28 --> CRSF cookie Set
DEBUG - 2014-10-08 17:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:30:28 --> Language Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Loader Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:30:28 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:30:28 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:30:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:30:28 --> Session Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:30:28 --> Session routines successfully run
DEBUG - 2014-10-08 17:30:28 --> Controller Class Initialized
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:30:28 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:28 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:30:28 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:30:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:30:28 --> Final output sent to browser
DEBUG - 2014-10-08 17:30:28 --> Total execution time: 0.2302
DEBUG - 2014-10-08 17:30:47 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:47 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:47 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Output Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Security Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Input Class Initialized
DEBUG - 2014-10-08 17:30:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:47 --> CRSF cookie Set
DEBUG - 2014-10-08 17:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:30:47 --> Language Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Loader Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:30:47 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:30:47 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:30:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:30:47 --> Session Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:30:47 --> Session routines successfully run
DEBUG - 2014-10-08 17:30:47 --> Controller Class Initialized
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:30:47 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:47 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:30:47 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:30:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:30:47 --> Final output sent to browser
DEBUG - 2014-10-08 17:30:47 --> Total execution time: 0.1611
DEBUG - 2014-10-08 17:30:54 --> Config Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:30:54 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:30:54 --> URI Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Router Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Output Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Security Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Input Class Initialized
DEBUG - 2014-10-08 17:30:54 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:54 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:54 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:54 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:54 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:54 --> XSS Filtering completed
DEBUG - 2014-10-08 17:30:54 --> CRSF cookie Set
DEBUG - 2014-10-08 17:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:30:54 --> Language Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Loader Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:30:54 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:30:54 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:30:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:30:54 --> Session Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:30:54 --> Session routines successfully run
DEBUG - 2014-10-08 17:30:54 --> Controller Class Initialized
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:30:54 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:54 --> Model Class Initialized
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:30:54 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:30:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:30:54 --> Final output sent to browser
DEBUG - 2014-10-08 17:30:54 --> Total execution time: 0.1526
DEBUG - 2014-10-08 17:31:04 --> Config Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:31:04 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:31:04 --> URI Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Router Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Output Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Security Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Input Class Initialized
DEBUG - 2014-10-08 17:31:04 --> XSS Filtering completed
DEBUG - 2014-10-08 17:31:04 --> XSS Filtering completed
DEBUG - 2014-10-08 17:31:04 --> XSS Filtering completed
DEBUG - 2014-10-08 17:31:04 --> XSS Filtering completed
DEBUG - 2014-10-08 17:31:04 --> XSS Filtering completed
DEBUG - 2014-10-08 17:31:04 --> XSS Filtering completed
DEBUG - 2014-10-08 17:31:04 --> CRSF cookie Set
DEBUG - 2014-10-08 17:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:31:04 --> Language Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Loader Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:31:04 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:31:04 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:31:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:31:04 --> Session Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:31:04 --> Session routines successfully run
DEBUG - 2014-10-08 17:31:04 --> Controller Class Initialized
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:31:04 --> Model Class Initialized
DEBUG - 2014-10-08 17:31:04 --> Model Class Initialized
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:31:04 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:31:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:31:04 --> Final output sent to browser
DEBUG - 2014-10-08 17:31:04 --> Total execution time: 0.1585
DEBUG - 2014-10-08 17:33:15 --> Config Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:33:15 --> URI Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Router Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Output Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Security Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Input Class Initialized
DEBUG - 2014-10-08 17:33:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:15 --> CRSF cookie Set
DEBUG - 2014-10-08 17:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:33:15 --> Language Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Loader Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:33:15 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:33:15 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:33:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:33:15 --> Session Class Initialized
DEBUG - 2014-10-08 17:33:15 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:33:15 --> Session routines successfully run
DEBUG - 2014-10-08 17:33:15 --> Controller Class Initialized
ERROR - 2014-10-08 17:33:15 --> 404 Page Not Found --> placement/1
DEBUG - 2014-10-08 17:33:20 --> Config Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:33:20 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:33:20 --> URI Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Router Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Output Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Security Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Input Class Initialized
DEBUG - 2014-10-08 17:33:20 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:20 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:20 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:20 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:20 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:20 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:20 --> CRSF cookie Set
DEBUG - 2014-10-08 17:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:33:20 --> Language Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Loader Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:33:20 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:33:20 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:33:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:33:20 --> Session Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:33:20 --> Session routines successfully run
DEBUG - 2014-10-08 17:33:20 --> Controller Class Initialized
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:33:20 --> Model Class Initialized
DEBUG - 2014-10-08 17:33:20 --> Model Class Initialized
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:33:20 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:33:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:33:20 --> Final output sent to browser
DEBUG - 2014-10-08 17:33:20 --> Total execution time: 0.1427
DEBUG - 2014-10-08 17:33:30 --> Config Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:33:30 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:33:30 --> URI Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Router Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Output Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Security Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Input Class Initialized
DEBUG - 2014-10-08 17:33:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:30 --> CRSF cookie Set
DEBUG - 2014-10-08 17:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:33:30 --> Language Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Loader Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:33:30 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:33:30 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:33:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:33:30 --> Session Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:33:30 --> Session routines successfully run
DEBUG - 2014-10-08 17:33:30 --> Controller Class Initialized
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:33:30 --> Model Class Initialized
DEBUG - 2014-10-08 17:33:30 --> Model Class Initialized
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:33:30 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:33:30 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:33:30 --> Final output sent to browser
DEBUG - 2014-10-08 17:33:30 --> Total execution time: 0.1764
DEBUG - 2014-10-08 17:33:33 --> Config Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:33:33 --> URI Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Router Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Output Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Security Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Input Class Initialized
DEBUG - 2014-10-08 17:33:33 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:33 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:33 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:33 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:33 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:33 --> XSS Filtering completed
DEBUG - 2014-10-08 17:33:33 --> CRSF cookie Set
DEBUG - 2014-10-08 17:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:33:33 --> Language Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Loader Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:33:33 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:33:33 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:33:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:33:33 --> Session Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:33:33 --> Session routines successfully run
DEBUG - 2014-10-08 17:33:33 --> Controller Class Initialized
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:33:33 --> Model Class Initialized
DEBUG - 2014-10-08 17:33:33 --> Model Class Initialized
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:33:33 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:33:33 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:33:33 --> Final output sent to browser
DEBUG - 2014-10-08 17:33:33 --> Total execution time: 0.2114
DEBUG - 2014-10-08 17:34:09 --> Config Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:34:09 --> URI Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Router Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Output Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Security Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Input Class Initialized
DEBUG - 2014-10-08 17:34:09 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:09 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:09 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:09 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:09 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:09 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:09 --> CRSF cookie Set
DEBUG - 2014-10-08 17:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:34:09 --> Language Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Loader Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:34:09 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:34:09 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:34:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:34:09 --> Session Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:34:09 --> Session routines successfully run
DEBUG - 2014-10-08 17:34:09 --> Controller Class Initialized
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:34:09 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:09 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:34:09 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:34:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:34:09 --> Final output sent to browser
DEBUG - 2014-10-08 17:34:09 --> Total execution time: 0.2009
DEBUG - 2014-10-08 17:34:12 --> Config Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:34:12 --> URI Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Router Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Output Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Security Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Input Class Initialized
DEBUG - 2014-10-08 17:34:12 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:12 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:12 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:12 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:12 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:12 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:12 --> CRSF cookie Set
DEBUG - 2014-10-08 17:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:34:12 --> Language Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Loader Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:34:12 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:34:12 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:34:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:34:12 --> Session Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:34:12 --> Session routines successfully run
DEBUG - 2014-10-08 17:34:12 --> Controller Class Initialized
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:34:12 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:12 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:34:12 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:34:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:34:12 --> Final output sent to browser
DEBUG - 2014-10-08 17:34:12 --> Total execution time: 0.1864
DEBUG - 2014-10-08 17:34:15 --> Config Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:34:15 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:34:15 --> URI Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Router Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Output Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Security Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Input Class Initialized
DEBUG - 2014-10-08 17:34:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:15 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:15 --> CRSF cookie Set
DEBUG - 2014-10-08 17:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:34:15 --> Language Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Loader Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:34:15 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:34:15 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:34:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:34:15 --> Session Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:34:15 --> Session routines successfully run
DEBUG - 2014-10-08 17:34:15 --> Controller Class Initialized
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:34:15 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:15 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:34:15 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:34:15 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:34:15 --> Final output sent to browser
DEBUG - 2014-10-08 17:34:15 --> Total execution time: 0.1666
DEBUG - 2014-10-08 17:34:24 --> Config Class Initialized
DEBUG - 2014-10-08 17:34:24 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:34:24 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:34:24 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:34:24 --> URI Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Router Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Output Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Security Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Input Class Initialized
DEBUG - 2014-10-08 17:34:25 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:25 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:25 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:25 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:25 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:25 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:25 --> CRSF cookie Set
DEBUG - 2014-10-08 17:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:34:25 --> Language Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Loader Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:34:25 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:34:25 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:34:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:34:25 --> Session Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:34:25 --> Session routines successfully run
DEBUG - 2014-10-08 17:34:25 --> Controller Class Initialized
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:34:25 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:25 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:34:25 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:34:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:34:25 --> Final output sent to browser
DEBUG - 2014-10-08 17:34:25 --> Total execution time: 0.1647
DEBUG - 2014-10-08 17:34:53 --> Config Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:34:53 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:34:53 --> URI Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Router Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Output Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Security Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Input Class Initialized
DEBUG - 2014-10-08 17:34:53 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:53 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:53 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:53 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:53 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:53 --> XSS Filtering completed
DEBUG - 2014-10-08 17:34:53 --> CRSF cookie Set
DEBUG - 2014-10-08 17:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:34:53 --> Language Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Loader Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:34:53 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:34:53 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:34:53 --> Session Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:34:53 --> Session routines successfully run
DEBUG - 2014-10-08 17:34:53 --> Controller Class Initialized
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:34:53 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:53 --> Model Class Initialized
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:34:53 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:34:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:34:53 --> Final output sent to browser
DEBUG - 2014-10-08 17:34:53 --> Total execution time: 0.1644
DEBUG - 2014-10-08 17:35:02 --> Config Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:35:02 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:35:02 --> URI Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Router Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Output Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Security Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Input Class Initialized
DEBUG - 2014-10-08 17:35:02 --> XSS Filtering completed
DEBUG - 2014-10-08 17:35:02 --> XSS Filtering completed
DEBUG - 2014-10-08 17:35:02 --> XSS Filtering completed
DEBUG - 2014-10-08 17:35:02 --> XSS Filtering completed
DEBUG - 2014-10-08 17:35:02 --> XSS Filtering completed
DEBUG - 2014-10-08 17:35:02 --> XSS Filtering completed
DEBUG - 2014-10-08 17:35:02 --> CRSF cookie Set
DEBUG - 2014-10-08 17:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:35:02 --> Language Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Loader Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:35:02 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:35:02 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:35:02 --> Session Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:35:02 --> Session routines successfully run
DEBUG - 2014-10-08 17:35:02 --> Controller Class Initialized
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:35:02 --> Model Class Initialized
DEBUG - 2014-10-08 17:35:02 --> Model Class Initialized
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:35:02 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:35:02 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:35:02 --> Final output sent to browser
DEBUG - 2014-10-08 17:35:02 --> Total execution time: 0.1613
DEBUG - 2014-10-08 17:35:44 --> Config Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:35:44 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:35:44 --> URI Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Router Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Output Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Security Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Input Class Initialized
DEBUG - 2014-10-08 17:35:44 --> CRSF cookie Set
DEBUG - 2014-10-08 17:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:35:44 --> Language Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Loader Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:35:44 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:35:44 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:35:44 --> Session Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:35:44 --> A session cookie was not found.
DEBUG - 2014-10-08 17:35:44 --> Session routines successfully run
DEBUG - 2014-10-08 17:35:44 --> Controller Class Initialized
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:35:44 --> Model Class Initialized
DEBUG - 2014-10-08 17:35:44 --> Model Class Initialized
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:35:44 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:35:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:35:44 --> Final output sent to browser
DEBUG - 2014-10-08 17:35:44 --> Total execution time: 0.1835
DEBUG - 2014-10-08 17:37:31 --> Config Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:37:31 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:37:31 --> URI Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Router Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Output Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Security Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Input Class Initialized
DEBUG - 2014-10-08 17:37:31 --> XSS Filtering completed
DEBUG - 2014-10-08 17:37:31 --> XSS Filtering completed
DEBUG - 2014-10-08 17:37:31 --> CRSF cookie Set
DEBUG - 2014-10-08 17:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:37:31 --> Language Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Loader Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:37:31 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:37:31 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:37:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:37:31 --> Session Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:37:31 --> Session routines successfully run
DEBUG - 2014-10-08 17:37:31 --> Controller Class Initialized
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:37:31 --> Model Class Initialized
DEBUG - 2014-10-08 17:37:31 --> Model Class Initialized
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:37:31 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:37:31 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:37:31 --> Final output sent to browser
DEBUG - 2014-10-08 17:37:31 --> Total execution time: 0.1316
DEBUG - 2014-10-08 17:37:36 --> Config Class Initialized
DEBUG - 2014-10-08 17:37:36 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:37:36 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:37:36 --> URI Class Initialized
DEBUG - 2014-10-08 17:37:36 --> Router Class Initialized
ERROR - 2014-10-08 17:37:36 --> 404 Page Not Found --> h
DEBUG - 2014-10-08 17:37:47 --> Config Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:37:47 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:37:47 --> URI Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Router Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Output Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Security Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Input Class Initialized
DEBUG - 2014-10-08 17:37:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:37:47 --> XSS Filtering completed
DEBUG - 2014-10-08 17:37:47 --> CRSF cookie Set
DEBUG - 2014-10-08 17:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:37:47 --> Language Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Loader Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:37:47 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:37:47 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:37:47 --> Session Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:37:47 --> Session routines successfully run
DEBUG - 2014-10-08 17:37:47 --> Controller Class Initialized
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:37:47 --> Model Class Initialized
DEBUG - 2014-10-08 17:37:47 --> Model Class Initialized
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:37:47 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:37:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:37:47 --> Final output sent to browser
DEBUG - 2014-10-08 17:37:47 --> Total execution time: 0.1483
DEBUG - 2014-10-08 17:37:55 --> Config Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:37:55 --> URI Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Router Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Output Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Security Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Input Class Initialized
DEBUG - 2014-10-08 17:37:55 --> XSS Filtering completed
DEBUG - 2014-10-08 17:37:55 --> XSS Filtering completed
DEBUG - 2014-10-08 17:37:55 --> CRSF cookie Set
DEBUG - 2014-10-08 17:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:37:55 --> Language Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Loader Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:37:55 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:37:55 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:37:55 --> Session Class Initialized
DEBUG - 2014-10-08 17:37:55 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:37:55 --> Session routines successfully run
DEBUG - 2014-10-08 17:37:55 --> Controller Class Initialized
ERROR - 2014-10-08 17:37:55 --> 404 Page Not Found --> placement/contact
DEBUG - 2014-10-08 17:38:00 --> Config Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:38:00 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:38:00 --> URI Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Router Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Output Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Security Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Input Class Initialized
DEBUG - 2014-10-08 17:38:00 --> XSS Filtering completed
DEBUG - 2014-10-08 17:38:00 --> XSS Filtering completed
DEBUG - 2014-10-08 17:38:00 --> CRSF cookie Set
DEBUG - 2014-10-08 17:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:38:00 --> Language Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Loader Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:38:00 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:38:00 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:38:00 --> Session Class Initialized
DEBUG - 2014-10-08 17:38:00 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:38:00 --> Session routines successfully run
DEBUG - 2014-10-08 17:38:00 --> Controller Class Initialized
ERROR - 2014-10-08 17:38:00 --> 404 Page Not Found --> placement/contactus
DEBUG - 2014-10-08 17:38:24 --> Config Class Initialized
DEBUG - 2014-10-08 17:38:24 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:38:24 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:38:24 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:38:24 --> URI Class Initialized
DEBUG - 2014-10-08 17:38:24 --> Router Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Config Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:40:26 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:40:26 --> URI Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Router Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Output Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Security Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Input Class Initialized
DEBUG - 2014-10-08 17:40:26 --> XSS Filtering completed
DEBUG - 2014-10-08 17:40:26 --> XSS Filtering completed
DEBUG - 2014-10-08 17:40:26 --> CRSF cookie Set
DEBUG - 2014-10-08 17:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:40:26 --> Language Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Loader Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:40:26 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:40:26 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:40:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:40:26 --> Session Class Initialized
DEBUG - 2014-10-08 17:40:26 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:40:26 --> Session routines successfully run
DEBUG - 2014-10-08 17:40:26 --> Controller Class Initialized
ERROR - 2014-10-08 17:40:26 --> 404 Page Not Found --> home/contactus
DEBUG - 2014-10-08 17:40:29 --> Config Class Initialized
DEBUG - 2014-10-08 17:40:29 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:40:29 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:40:29 --> URI Class Initialized
DEBUG - 2014-10-08 17:40:29 --> Router Class Initialized
DEBUG - 2014-10-08 17:40:29 --> Output Class Initialized
DEBUG - 2014-10-08 17:40:29 --> Security Class Initialized
DEBUG - 2014-10-08 17:40:30 --> Input Class Initialized
DEBUG - 2014-10-08 17:40:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:40:30 --> XSS Filtering completed
DEBUG - 2014-10-08 17:40:30 --> CRSF cookie Set
DEBUG - 2014-10-08 17:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:40:30 --> Language Class Initialized
DEBUG - 2014-10-08 17:40:30 --> Loader Class Initialized
DEBUG - 2014-10-08 17:40:30 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:40:30 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:40:30 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:40:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:40:30 --> Session Class Initialized
DEBUG - 2014-10-08 17:40:30 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:40:30 --> Session routines successfully run
DEBUG - 2014-10-08 17:40:30 --> Controller Class Initialized
DEBUG - 2014-10-08 17:40:30 --> Final output sent to browser
DEBUG - 2014-10-08 17:40:30 --> Total execution time: 0.0775
DEBUG - 2014-10-08 17:41:31 --> Config Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:41:31 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:41:31 --> URI Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Router Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Output Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Security Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Input Class Initialized
DEBUG - 2014-10-08 17:41:31 --> XSS Filtering completed
DEBUG - 2014-10-08 17:41:31 --> XSS Filtering completed
DEBUG - 2014-10-08 17:41:31 --> CRSF cookie Set
DEBUG - 2014-10-08 17:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:41:31 --> Language Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Loader Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:41:31 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:41:31 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:41:31 --> Session Class Initialized
DEBUG - 2014-10-08 17:41:31 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:41:31 --> Session routines successfully run
DEBUG - 2014-10-08 17:41:31 --> Controller Class Initialized
DEBUG - 2014-10-08 17:41:31 --> File loaded: application/views/bootstrap/header.php
DEBUG - 2014-10-08 17:41:31 --> File loaded: application/views/bootstrap/nav.php
DEBUG - 2014-10-08 17:41:31 --> File loaded: application/views/home_body.php
DEBUG - 2014-10-08 17:41:31 --> File loaded: application/views/bootstrap/secondary.php
DEBUG - 2014-10-08 17:41:31 --> File loaded: application/views/bootstrap/footer.php
DEBUG - 2014-10-08 17:41:31 --> Final output sent to browser
DEBUG - 2014-10-08 17:41:31 --> Total execution time: 0.1882
DEBUG - 2014-10-08 17:42:07 --> Config Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:42:07 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:42:07 --> URI Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Router Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Output Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Security Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Input Class Initialized
DEBUG - 2014-10-08 17:42:07 --> XSS Filtering completed
DEBUG - 2014-10-08 17:42:07 --> XSS Filtering completed
DEBUG - 2014-10-08 17:42:07 --> CRSF cookie Set
DEBUG - 2014-10-08 17:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:42:07 --> Language Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Loader Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:42:07 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:42:07 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:42:07 --> Session Class Initialized
DEBUG - 2014-10-08 17:42:07 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:42:07 --> Session routines successfully run
DEBUG - 2014-10-08 17:42:07 --> Controller Class Initialized
DEBUG - 2014-10-08 17:42:07 --> File loaded: application/views/bootstrap/header.php
DEBUG - 2014-10-08 17:42:07 --> File loaded: application/views/bootstrap/nav.php
DEBUG - 2014-10-08 17:42:07 --> File loaded: application/views/home_body.php
DEBUG - 2014-10-08 17:42:07 --> File loaded: application/views/bootstrap/secondary.php
DEBUG - 2014-10-08 17:42:07 --> File loaded: application/views/bootstrap/footer.php
DEBUG - 2014-10-08 17:42:07 --> Final output sent to browser
DEBUG - 2014-10-08 17:42:07 --> Total execution time: 0.0956
DEBUG - 2014-10-08 17:42:36 --> Config Class Initialized
DEBUG - 2014-10-08 17:42:36 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:42:36 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:42:36 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:42:36 --> URI Class Initialized
DEBUG - 2014-10-08 17:42:36 --> Router Class Initialized
DEBUG - 2014-10-08 17:42:51 --> Config Class Initialized
DEBUG - 2014-10-08 17:42:51 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:42:51 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:42:51 --> URI Class Initialized
DEBUG - 2014-10-08 17:42:51 --> Router Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Config Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:42:58 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:42:58 --> URI Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Router Class Initialized
DEBUG - 2014-10-08 17:42:58 --> No URI present. Default controller set.
DEBUG - 2014-10-08 17:42:58 --> Output Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Security Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Input Class Initialized
DEBUG - 2014-10-08 17:42:58 --> XSS Filtering completed
DEBUG - 2014-10-08 17:42:58 --> XSS Filtering completed
DEBUG - 2014-10-08 17:42:58 --> CRSF cookie Set
DEBUG - 2014-10-08 17:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:42:58 --> Language Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Loader Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:42:58 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:42:58 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:42:58 --> Session Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:42:58 --> Session routines successfully run
DEBUG - 2014-10-08 17:42:58 --> Controller Class Initialized
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:42:58 --> Model Class Initialized
DEBUG - 2014-10-08 17:42:58 --> Model Class Initialized
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:42:58 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:42:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:42:58 --> Final output sent to browser
DEBUG - 2014-10-08 17:42:58 --> Total execution time: 0.1106
DEBUG - 2014-10-08 17:43:01 --> Config Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:43:01 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:43:01 --> URI Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Router Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Output Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Security Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Input Class Initialized
DEBUG - 2014-10-08 17:43:01 --> XSS Filtering completed
DEBUG - 2014-10-08 17:43:01 --> XSS Filtering completed
DEBUG - 2014-10-08 17:43:01 --> CRSF cookie Set
DEBUG - 2014-10-08 17:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:43:01 --> Language Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Loader Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:43:01 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:43:01 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:43:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:43:01 --> Session Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:43:01 --> Session routines successfully run
DEBUG - 2014-10-08 17:43:01 --> Controller Class Initialized
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:43:01 --> Model Class Initialized
DEBUG - 2014-10-08 17:43:01 --> Model Class Initialized
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/placement_news.php
DEBUG - 2014-10-08 17:43:01 --> Helper loaded: form_helper
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/exam_login_sidebar.php
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/placement_instructions.php
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:43:01 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:43:01 --> Final output sent to browser
DEBUG - 2014-10-08 17:43:01 --> Total execution time: 0.1134
DEBUG - 2014-10-08 17:43:03 --> Config Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Hooks Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Utf8 Class Initialized
DEBUG - 2014-10-08 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2014-10-08 17:43:03 --> URI Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Router Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Output Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Security Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Input Class Initialized
DEBUG - 2014-10-08 17:43:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:43:03 --> XSS Filtering completed
DEBUG - 2014-10-08 17:43:03 --> CRSF cookie Set
DEBUG - 2014-10-08 17:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-10-08 17:43:03 --> Language Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Loader Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Helper loaded: functions_helper
DEBUG - 2014-10-08 17:43:03 --> Helper loaded: url_helper
DEBUG - 2014-10-08 17:43:03 --> Database Driver Class Initialized
ERROR - 2014-10-08 17:43:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-10-08 17:43:03 --> Session Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Helper loaded: string_helper
DEBUG - 2014-10-08 17:43:03 --> Session routines successfully run
DEBUG - 2014-10-08 17:43:03 --> Controller Class Initialized
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-10-08 17:43:03 --> Model Class Initialized
DEBUG - 2014-10-08 17:43:03 --> Model Class Initialized
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/under_construction/index.php
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/under_construction.php
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/placement_history.php
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-10-08 17:43:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-10-08 17:43:03 --> Final output sent to browser
DEBUG - 2014-10-08 17:43:03 --> Total execution time: 0.1297
